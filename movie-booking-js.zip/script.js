const bookBtn = document.getElementById("bookBtn");
const closeBtn = document.getElementById("closeBtn");
const confirmBtn = document.getElementById("confirmBtn");
const doneBtn = document.getElementById("doneBtn");

const bookingWindow = document.getElementById("bookingWindow");
const successWindow = document.getElementById("successWindow");
const seatsInput = document.getElementById("seats");
const total = document.getElementById("total");

const ticketPrice = 200;

// Open booking window
bookBtn.addEventListener("click", function () {
    bookingWindow.style.display = "flex";
});

// Calculate total price
seatsInput.addEventListener("input", function () {
    let seats = Number(seatsInput.value);

    if (seats < 1) seats = 1;
    if (seats > 10) seats = 10;

    seatsInput.value = seats;
    total.textContent = seats * ticketPrice;
});

// Close booking window
closeBtn.addEventListener("click", function () {
    bookingWindow.style.display = "none";
});

// Confirm booking
confirmBtn.addEventListener("click", function () {
    const seats = Number(seatsInput.value);

    if (seats <= 0) {
        alert("Please select at least one seat.");
        return;
    }

    // Close booking window after successful booking
    bookingWindow.style.display = "none";

    // Show success window
    successWindow.style.display = "flex";
});

// Close success window
doneBtn.addEventListener("click", function () {
    successWindow.style.display = "none";
});
